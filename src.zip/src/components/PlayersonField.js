

// const PlayersOnField = (props) => {

//     let {playersName} = props;

//     return (
//         <>
        
//         <ul>
//             {playersName.map((item,i) => {
    
//                 return <li>{item}</li>})}
//         </ul>
//         </>
//     )
    
// }

// export default PlayersOnField