let initState = {
    backgroundColor : 'blue',
    team:'Chelsea',
    teamType: 'real',
}

export const reducer = (state=initState, action={}) => {
    // switch (action.type) {
    //     case value:
            
    //         break;
    
    //     default:
    //         break;
    // }
}